import React from 'react'
import "./Header.css"
import profile from "./profile.jpg"

function Header() {
  return (
    <header>
        <div className='logo'>
            <img src={profile} alt=''/><span>MediCare</span>
        </div>
    </header>
  )
}

export default Header;
