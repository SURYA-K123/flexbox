import React from 'react'
import "./Content.css"

function Content() {
  return (
    <div className='main-content'>
      
    </div>
  )
}

export default Content
