import React from "react";
import "./Sidebar.css";
import profile from "./profile.jpg";

function Sidebar() {
  return (
    <div className="sidebar">
      <div className="profile">
        <img src={profile} alt="" />
        <div className="profile-text">
          <p>Profile Name</p>
          <p>Administrator </p>
        </div>
      </div>
      <ul className="menus">
        <li>
          <a href="#">
            <i className="fa fa-bar-chart"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-ambulance"></i>
            <span>Inventory</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-medkit"></i>
            <span>Medicine Types</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-file-o"></i>
            <span>Category</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-user-circle"></i>
            <span>Profile</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i className="fa fa-power-off"></i>
            <span>Logout</span>
          </a>
        </li>
      </ul>
    </div>
  );
}

export default Sidebar;
